import axios from 'axios';

const API_URL = 'http://192.168.1.13:8000/api/login';

// export const login = async (username, password) => {
//     console.log(username, password);
//     try {
//         const response = await axios.post(API_URL, {
//             username,
//             password
//         },{
//             withCredentials: true
//         });

//         const token = response.data.token;

//         setItemWithExpiry('jwtToken', token, 500);

//         return response.data;
//     } catch (error) {
//         console.error("Login failed", error);
//         throw error;
//     }
// };


export const login = async (username, password) => {
    console.log(username, password);
    try {
        const response = await axios.post(API_URL, {
            username,
            password
        },{
            withCredentials: true
        });
        return response.data;
    } catch (error) {
        console.error("Login failed", error);
        throw error;
    }
};


const setItemWithExpiry = (key, value, ttl) => {
    const now = new Date();

    const item = {
        value: value,
        expiry: now.getTime() + ttl,
    };

    localStorage.setItem(key, JSON.stringify(item));
};

export const getItemWithExpiry = (key) => {
    const item = localStorage.getItem(key);

    if (!item) {
        return null;
    }

    const now = new Date();

    if (now.getTime() > item.expiry) {
        localStorage.removeItem(key);
        return null;
    }

    return item;
};
