import axios from 'axios';
// import { getItemWithExpiry } from './loginService';

const API_URL = 'http://192.168.1.13:8000/api/test';

export const getUserData = async () => {
    // const token = getItemWithExpiry('jwtToken');
    // if (!token) {
    //     throw new Error('No token found');
    // }
    // console.log('token: ', token);
    try {
        const response = await axios.get(API_URL, {
            // headers: {
            //     'Authorization': `Bearer ${token}`
            // },
            withCredentials: true
        });
        return response.data;
    } catch (error) {
        console.error("Failed to get user data", error);
        throw error;
    }
};