'use client'
import { useEffect } from 'react';
import { Inter } from 'next/font/google'
import './globals.css'
import Sidebar from './components/Navigation/Sidebar'
import Navbar from './components/Navigation/Navbar'
import { usePathname, useRouter } from 'next/navigation'
import { getItemWithExpiry } from './services/loginService'

const inter = Inter({ subsets: ['latin'] })


export default function RootLayout({ children }) {
  const route = usePathname();
  const router = useRouter();

  useEffect(() => {
    const token = getItemWithExpiry('jwtToken');

    if (!token) {
      router.push('/');
    }
  }, [route, router]);

  return (
    <html lang="en">
      <body className={inter.className}>
        {route !== '/' && <Sidebar />}
        <main className='mainContainer'>
          {route !== '/' && <Navbar />}
          {children}
        </main>
      </body>
    </html>
  )
}
