import React from 'react'
import { Input } from '@nextui-org/input'
import { DatePicker } from "@nextui-org/date-picker";
import { parseDate, getLocalTimeZone } from "@internationalized/date";

const page = () => {
  return (
    <div className="mainBlock">
      <h2 className="title">Общая информация</h2>
      <div className="infoContainer">
        <div className="infoInputWraper">
          <span>ФИО</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>

        <div className="infoInputWraper">
          <span>COOP</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>

        <div className="infoInputWraper">
          <span>Дата рождения</span>
          <DatePicker variant="bordered" size="lg" radius="none" />
        </div>

        <div className="infoInputWraper">
          <span>Электронный адрес</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>

        <div className="infoInputWraper">
          <span>Номер телефона</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>

        <div className="infoInputWraper">
          <span>Гражданство РК / Вид на жительство</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>

        <div className="infoInputWraper">
          <span>Семейное положение/</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>

        <div className="infoInputWraper">
          <span>Средний доход за последние 6 месяцев</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>

        <div className="infoInputWraper">
          <span>Источник первоначальных взносов</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>

        <div className='plank'>
          Документы
        </div>

        <div className="infoInputWraper">
          <span>Тип документа</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>

        <div className="infoInputWraper">
          <span>Номер документа</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>

        <div className="infoInputWraper">
          <span>Дата выдачи</span>
          <DatePicker variant="bordered" size="lg" radius="none" />
        </div>

        <div className="infoInputWraper">
          <span>Орган выдавший документ</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>

        <div className="infoInputWraper">
          <span>Адрес регистрации</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>

        <div className='plank'>
          Недвижимость
        </div>

        <div className="infoInputWraper">
          <span>Желаемый регион приобретения объекта</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>

        <div className="infoInputWraper">
          <span>Вид объекта недвижимости</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>

        <div className="infoInputWraper">
          <span>Общая площадь (не менее м.кв)</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>

        <div className="infoInputWraper">
          <span>Ориентировочная стоимость</span>
          <Input type="text" variant="bordered" size="lg" radius="none"  />
        </div>
      </div>
    </div>
  )
}

export default page